# Autonomous Multi-Agent Alpha & Macro War-Room — Phase 1

這是一個以 Python 3.11、FastAPI、Pydantic v2、Google Gemini Structured Outputs、yfinance、pandas 與 numpy 建成的非同步宏觀／量化對沖推演核心。系統預設採「可降級」設計：市場資料、RSS 或 Gemini 暫時不可用時會保留錯誤資訊並回傳可人工覆核的結果，不會靜默捏造行情。

## 架構

```mermaid
flowchart LR
  API[FastAPI /analyze] --> C[Async Intelligence Collector]
  C --> RSS[Macro RSS]
  C --> YF[yfinance OHLCV]
  C --> D[Debate Engine]
  D --> A[Agent A Bull]
  D --> B[Agent B Risk]
  D --> Q[Agent C Quant]
  A --> CIO[Agent D CIO JSON]
  B --> CIO
  Q --> CIO
  CIO --> BT[3Y Vector Backtester]
  BT --> R[WarRoomBriefing]
  R --> API
```

## 本地運行

```bash
cd alpha-war-room
python3.11 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# 編輯 .env，填入 GEMINI_API_KEY
uvicorn src.main:app --reload --port 8080
```

呼叫：

```bash
curl -X POST http://localhost:8080/api/v1/analyze \
  -H 'content-type: application/json' \
  -d '{"event":"央行意外轉向寬鬆","symbols":["SPY","QQQ","GLD","BTC-USD"],"debate_rounds":2}'

curl http://localhost:8080/api/v1/latest-briefing
```

## 測試

```bash
pytest -q
```

測試不需要 API key，也不需要網路行情：Collector、Gemini response、Pydantic schema、回測指標與 FastAPI pipeline 都可注入 fake／mock。

## Gemini 設計

`src/agents.py` 透過官方 `google-genai` SDK，為每個角色使用獨立 system instruction，設定 `response_mime_type="application/json"`、`response_schema`，並啟用 `GoogleSearch` grounding tool。API key 僅由 `GEMINI_API_KEY` 環境變數讀取。若 key 缺失或模型失敗，Agent 層返回 confidence 0 的人工覆核訊息。

## GitHub Actions 與快照

`.github/workflows/ci-cd.yml` 在 push 時執行測試，在排程觸發時執行 `scripts/generate_snapshot.py`，將最新結果輸出為 `data/latest_war_room.json` 並上傳 artifact。Repository Settings → Secrets and variables → Actions → New repository secret，建立 `GEMINI_API_KEY`。建議另行設定受限權限的 cloud storage 或 artifact retention policy。

## Google Cloud Run 部署

```bash
gcloud auth login
gcloud config set project YOUR_PROJECT_ID
gcloud builds submit --tag gcr.io/YOUR_PROJECT_ID/alpha-war-room
gcloud run deploy alpha-war-room \
  --image gcr.io/YOUR_PROJECT_ID/alpha-war-room \
  --platform managed --region asia-east1 --allow-unauthenticated \
  --set-env-vars GEMINI_MODEL=gemini-2.5-flash \
  --set-secrets GEMINI_API_KEY=gemini-api-key:latest
```

先在 Secret Manager 建立 secret：

```bash
echo -n "$GEMINI_API_KEY" | gcloud secrets create gemini-api-key --data-file=-
gcloud secrets add-iam-policy-binding gemini-api-key \
  --member="serviceAccount:YOUR_CLOUD_RUN_SERVICE_ACCOUNT" \
  --role="roles/secretmanager.secretAccessor"
```

Cloud Run 透過 `$PORT` 啟動 Uvicorn，Dockerfile 已符合無狀態容器與 health endpoint 的基本要求。生產環境應在 API Gateway／IAP 前加認證、限流、審計與成本預算。

## 風險與邊界

這是研究與模擬引擎，不是投資建議或自動下單系統。yfinance 與 RSS 屬公開資料，可能延遲、缺漏或受供應商限制；所有 CIO 裁決在執行前都應由人員覆核，並加上交易限額、停損和 kill switch。
