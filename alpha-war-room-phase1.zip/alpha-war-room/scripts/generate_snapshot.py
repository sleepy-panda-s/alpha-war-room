import asyncio
import json
from pathlib import Path

from src.main import run_analysis
from src.models import AnalyzeRequest

async def main() -> None:
    briefing = await run_analysis(AnalyzeRequest(event="Scheduled macro and cross-asset update"))
    output = Path("data/latest_war_room.json")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(briefing.model_dump(mode="json"), ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"wrote {output}")

if __name__ == "__main__":
    asyncio.run(main())
