from __future__ import annotations

import asyncio
import json
import os
from typing import Any

from google import genai
from google.genai import types

from .models import AgentArgument, CIOVerdict, IntelligenceSnapshot

AGENT_INSTRUCTIONS = {
    "Agent A": "你是激進多頭分析師：尋找催化劑、動能與不對稱上行機會；必須同時列出可證偽風險。",
    "Agent B": "你是冷酷空頭風控官：專注找出邏輯漏洞、流動性風險、估值壓力與黑天鵝隱患。",
    "Agent C": "你是宏觀量化策略師：結合歷史相關性、價格動能與回測數據，客觀評估機率與風險回報。",
    "Agent D": "你是首席投資官 CIO：綜合三方論點，輸出嚴格符合 schema 的最終裁決。",
}

ARGUMENT_SCHEMA = {
    "type": "object", "properties": {
        "agent": {"type": "string"}, "stance": {"type": "string"},
        "points": {"type": "array", "items": {"type": "string"}},
        "risks": {"type": "array", "items": {"type": "string"}},
        "confidence": {"type": "integer", "minimum": 0, "maximum": 100},
    }, "required": ["agent", "stance", "points", "risks", "confidence"]
}
VERDICT_SCHEMA = {
    "type": "object", "properties": {
        "event_rating": {"type": "string", "enum": ["LOW", "MEDIUM", "HIGH", "CRITICAL"]},
        "recommended_assets": {"type": "array", "items": {"type": "string"}},
        "direction": {"type": "string", "enum": ["LONG", "SHORT", "HEDGE", "NEUTRAL"]},
        "confidence": {"type": "integer", "minimum": 0, "maximum": 100},
        "core_logic_summary": {"type": "string"}, "hedge_recommendation": {"type": "string"},
        "rationale": {"type": "array", "items": {"type": "string"}},
    }, "required": ["event_rating", "recommended_assets", "direction", "confidence", "core_logic_summary", "hedge_recommendation", "rationale"]
}

class DebateEngine:
    def __init__(self, client: Any | None = None, model: str | None = None):
        self.client = client
        self.model = model or os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
        if self.client is None and os.getenv("GEMINI_API_KEY"):
            self.client = genai.Client(api_key=os.environ["GEMINI_API_KEY"])

    async def _generate(self, instruction: str, prompt: str, schema: dict[str, Any]) -> dict[str, Any]:
        if self.client is None:
            raise RuntimeError("GEMINI_API_KEY is not configured")
        config = types.GenerateContentConfig(system_instruction=instruction, response_mime_type="application/json", response_schema=schema, tools=[types.Tool(google_search=types.GoogleSearch())])
        response = await asyncio.to_thread(self.client.models.generate_content, model=self.model, contents=prompt, config=config)
        text = getattr(response, "text", None) or "{}"
        return json.loads(text)

    async def debate(self, event: str, intelligence: IntelligenceSnapshot, rounds: int = 2) -> list[AgentArgument]:
        context = json.dumps({"event": event, "intelligence": intelligence.model_dump(mode="json")}, ensure_ascii=False)
        async def ask(agent: str) -> AgentArgument:
            prompt = f"事件與情報：{context}\n這是第 {rounds} 輪辯論。請以 JSON 回答，提出可操作且有依據的論點。"
            try:
                return AgentArgument.model_validate(await self._generate(AGENT_INSTRUCTIONS[agent], prompt, ARGUMENT_SCHEMA))
            except Exception as exc:
                return AgentArgument(agent=agent, stance="UNAVAILABLE", points=[f"AI unavailable: {exc}"], risks=["需人工覆核"], confidence=0)
        results = []
        for _ in range(rounds):
            results.extend(await asyncio.gather(*(ask(a) for a in ["Agent A", "Agent B", "Agent C"])))
        return results

    async def verdict(self, event: str, intelligence: IntelligenceSnapshot, debate: list[AgentArgument]) -> CIOVerdict:
        prompt = json.dumps({"event": event, "intelligence": intelligence.model_dump(mode="json"), "debate": [a.model_dump() for a in debate]}, ensure_ascii=False)
        try:
            return CIOVerdict.model_validate(await self._generate(AGENT_INSTRUCTIONS["Agent D"], prompt, VERDICT_SCHEMA))
        except Exception as exc:
            return CIOVerdict(event_rating="MEDIUM", recommended_assets=[a.symbol for a in intelligence.assets[:1]] or ["SPY"], direction="NEUTRAL", confidence=0, core_logic_summary=f"CIO unavailable; manual review required: {exc}", hedge_recommendation="保持現金與小倉位，等待人工覆核", rationale=["結構化 AI 裁決不可用"])
