from __future__ import annotations

import asyncio
import math
from typing import Callable

import numpy as np
import pandas as pd
import yfinance as yf

from .models import BacktestMetrics, Direction


def momentum_strategy(close: pd.Series, direction: Direction = Direction.LONG, lookback: int = 20) -> pd.Series:
    signal = (close > close.rolling(lookback).mean()).astype(float)
    if direction == Direction.SHORT:
        signal = -signal
    return signal.shift(1).fillna(0.0)


def calculate_metrics(close: pd.Series, symbol: str, direction: Direction = Direction.LONG, data_source: str = "yfinance") -> BacktestMetrics:
    close = pd.Series(close).dropna().astype(float)
    if len(close) < 2:
        return BacktestMetrics(symbol=symbol, period_days=0, annualized_return=0.0, sharpe_ratio=0.0, max_drawdown=0.0, win_rate=0.0, trades=0, data_source=data_source)
    asset_returns = close.pct_change().fillna(0.0)
    signals = momentum_strategy(close, direction)
    strategy_returns = asset_returns * signals
    equity = (1 + strategy_returns).cumprod()
    years = max(len(close) / 252, 1 / 252)
    annualized = float(equity.iloc[-1] ** (1 / years) - 1)
    vol = float(strategy_returns.std() * math.sqrt(252))
    sharpe = float(strategy_returns.mean() / strategy_returns.std() * math.sqrt(252)) if strategy_returns.std() > 0 else 0.0
    drawdown = equity / equity.cummax() - 1
    wins = int((strategy_returns > 0).sum())
    active = int((signals != 0).sum())
    return BacktestMetrics(symbol=symbol, period_days=len(close), annualized_return=annualized, sharpe_ratio=sharpe, max_drawdown=float(drawdown.min()), win_rate=(wins / active if active else 0.0), trades=int(((signals != signals.shift(1)) & (signals != 0)).sum()), data_source=data_source)


class Backtester:
    def __init__(self, loader: Callable[[str], pd.Series] | None = None):
        self.loader = loader or self._load

    @staticmethod
    def _load(symbol: str) -> pd.Series:
        data = yf.download(symbol, period="3y", interval="1d", progress=False, auto_adjust=True, threads=False)
        if data.empty:
            raise ValueError(f"no data for {symbol}")
        close = data["Close"]
        return close.iloc[:, 0] if getattr(close, "ndim", 1) > 1 else close

    async def run(self, symbol: str, direction: Direction = Direction.LONG) -> BacktestMetrics:
        try:
            close = await asyncio.to_thread(self.loader, symbol)
            return calculate_metrics(close, symbol, direction)
        except Exception:
            return BacktestMetrics(symbol=symbol, period_days=0, annualized_return=0.0, sharpe_ratio=0.0, max_drawdown=0.0, win_rate=0.0, trades=0, data_source="unavailable")
