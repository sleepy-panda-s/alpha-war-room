from __future__ import annotations

import asyncio
import logging
import math
from datetime import datetime, timezone
from typing import Any, Callable

import feedparser
import yfinance as yf

from .models import AssetSnapshot, IntelligenceSnapshot, NewsItem

logger = logging.getLogger(__name__)
DEFAULT_FEEDS = [
    "https://feeds.reuters.com/reuters/businessNews",
    "https://www.cnbc.com/id/100003114/device/rss/rss.html",
]


async def with_retry(fn: Callable[[], Any], retries: int = 3, base_delay: float = 0.25) -> Any:
    last: Exception | None = None
    for attempt in range(retries):
        try:
            result = fn()
            if asyncio.iscoroutine(result):
                result = await result
            return result
        except Exception as exc:
            last = exc
            if attempt == retries - 1:
                break
            await asyncio.sleep(base_delay * (2 ** attempt))
    raise last or RuntimeError("operation failed")


def _parse_feed(url: str, limit: int = 10) -> list[NewsItem]:
    parsed = feedparser.parse(url)
    source = parsed.feed.get("title", url)
    return [NewsItem(title=e.get("title", "Untitled"), url=e.get("link", ""), summary=e.get("summary", "")[:1000], source=source) for e in parsed.entries[:limit]]


def _download_asset(symbol: str, period: str = "1y") -> AssetSnapshot:
    hist = yf.download(symbol, period=period, interval="1d", progress=False, auto_adjust=False, threads=False)
    if hist is None or hist.empty:
        raise ValueError(f"no market data for {symbol}")
    close = hist["Close"]
    if hasattr(close, "iloc") and getattr(close, "ndim", 1) > 1:
        close = close.iloc[:, 0]
    close = close.dropna()
    if len(close) == 0:
        raise ValueError(f"no close data for {symbol}")
    returns = close.pct_change().dropna()
    price = float(close.iloc[-1])
    change = float((close.iloc[-1] / close.iloc[-2] - 1) * 100) if len(close) > 1 else 0.0
    vol = float(returns.std() * math.sqrt(252)) if len(returns) > 1 else 0.0
    return AssetSnapshot(symbol=symbol, price=price, change_pct=change, volatility_annualized=vol, source="yfinance")


class IntelligenceCollector:
    def __init__(self, feeds: list[str] | None = None, asset_loader: Callable[[str], Any] | None = None):
        self.feeds = feeds or DEFAULT_FEEDS
        self.asset_loader = asset_loader or _download_asset

    async def collect(self, symbols: list[str]) -> IntelligenceSnapshot:
        errors: list[str] = []
        async def get_news(url: str) -> list[NewsItem]:
            return await with_retry(lambda: asyncio.to_thread(_parse_feed, url))
        news_results = await asyncio.gather(*(get_news(f) for f in self.feeds), return_exceptions=True)
        news: list[NewsItem] = []
        for result in news_results:
            if isinstance(result, Exception):
                errors.append(f"news: {result}")
            else:
                news.extend(result)
        async def get_asset(symbol: str) -> AssetSnapshot:
            return await with_retry(lambda: asyncio.to_thread(self.asset_loader, symbol))
        asset_results = await asyncio.gather(*(get_asset(s) for s in symbols), return_exceptions=True)
        assets: list[AssetSnapshot] = []
        for symbol, result in zip(symbols, asset_results):
            if isinstance(result, Exception):
                errors.append(f"asset {symbol}: {result}")
                assets.append(AssetSnapshot(symbol=symbol, source="degraded"))
            else:
                assets.append(result)
        return IntelligenceSnapshot(assets=assets, news=news[:50], degraded=bool(errors), errors=errors, collected_at=datetime.now(timezone.utc))
