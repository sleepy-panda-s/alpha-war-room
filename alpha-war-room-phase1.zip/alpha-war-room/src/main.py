from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException

from .agents import DebateEngine
from .backtester import Backtester
from .collector import IntelligenceCollector
from .models import AnalyzeRequest, WarRoomBriefing

app = FastAPI(title="Autonomous Alpha & Macro War-Room", version="1.0.0")
_latest: WarRoomBriefing | None = None

async def run_analysis(request: AnalyzeRequest, collector: Any | None = None, debate_engine: Any | None = None, backtester: Any | None = None) -> WarRoomBriefing:
    collector = collector or IntelligenceCollector()
    debate_engine = debate_engine or DebateEngine()
    backtester = backtester or Backtester()
    intelligence = await collector.collect(request.symbols)
    debate = await debate_engine.debate(request.event, intelligence, request.debate_rounds)
    verdict = await debate_engine.verdict(request.event, intelligence, debate)
    verdict.backtests = [await backtester.run(symbol, verdict.direction) for symbol in verdict.recommended_assets]
    return WarRoomBriefing(event=request.event, intelligence=intelligence, debate=debate, verdict=verdict)

@app.get("/healthz")
async def healthz() -> dict[str, str]:
    return {"status": "ok"}

@app.post("/api/v1/analyze", response_model=WarRoomBriefing)
async def analyze(request: AnalyzeRequest) -> WarRoomBriefing:
    global _latest
    try:
        _latest = await run_analysis(request)
        return _latest
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

@app.get("/api/v1/latest-briefing", response_model=WarRoomBriefing)
async def latest_briefing() -> WarRoomBriefing:
    if _latest is not None:
        return _latest
    path = Path("data/latest_war_room.json")
    if path.exists():
        return WarRoomBriefing.model_validate_json(path.read_text())
    raise HTTPException(status_code=404, detail="No briefing available")
