from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, ConfigDict


class Direction(str, Enum):
    LONG = "LONG"
    SHORT = "SHORT"
    HEDGE = "HEDGE"
    NEUTRAL = "NEUTRAL"


class EventRating(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class AssetSnapshot(BaseModel):
    model_config = ConfigDict(extra="forbid")
    symbol: str
    price: float | None = None
    change_pct: float | None = None
    volatility_annualized: float | None = None
    source: str = "unavailable"
    observed_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class NewsItem(BaseModel):
    model_config = ConfigDict(extra="forbid")
    title: str
    url: str = ""
    summary: str = ""
    published_at: datetime | None = None
    source: str = "unknown"


class IntelligenceSnapshot(BaseModel):
    model_config = ConfigDict(extra="forbid")
    assets: list[AssetSnapshot] = Field(default_factory=list)
    news: list[NewsItem] = Field(default_factory=list)
    collected_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    degraded: bool = False
    errors: list[str] = Field(default_factory=list)


class BacktestMetrics(BaseModel):
    model_config = ConfigDict(extra="forbid")
    symbol: str
    period_days: int = Field(ge=0)
    annualized_return: float
    sharpe_ratio: float
    max_drawdown: float
    win_rate: float = Field(ge=0, le=1)
    trades: int = Field(ge=0)
    data_source: str = "yfinance"


class AgentArgument(BaseModel):
    model_config = ConfigDict(extra="forbid")
    agent: str
    stance: str
    points: list[str] = Field(min_length=1)
    risks: list[str] = Field(default_factory=list)
    confidence: int = Field(ge=0, le=100)


class CIOVerdict(BaseModel):
    model_config = ConfigDict(extra="forbid")
    event_rating: EventRating
    recommended_assets: list[str] = Field(min_length=1)
    direction: Direction
    confidence: int = Field(ge=0, le=100)
    core_logic_summary: str = Field(min_length=1)
    hedge_recommendation: str = Field(min_length=1)
    rationale: list[str] = Field(default_factory=list)
    backtests: list[BacktestMetrics] = Field(default_factory=list)
    generated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class AnalyzeRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    event: str = Field(min_length=3, max_length=10000)
    symbols: list[str] = Field(default_factory=lambda: ["SPY", "QQQ", "GLD", "BTC-USD", "CL=F"], min_length=1)
    debate_rounds: int = Field(default=2, ge=1, le=5)


class WarRoomBriefing(BaseModel):
    model_config = ConfigDict(extra="forbid")
    event: str
    intelligence: IntelligenceSnapshot
    debate: list[AgentArgument]
    verdict: CIOVerdict
    generated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class GeminiResponse(BaseModel):
    model_config = ConfigDict(extra="allow")
    argument: AgentArgument | None = None
    verdict: CIOVerdict | None = None
    raw: dict[str, Any] = Field(default_factory=dict)
