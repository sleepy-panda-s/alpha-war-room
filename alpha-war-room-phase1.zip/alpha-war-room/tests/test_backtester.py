import numpy as np
import pandas as pd
import pytest

from src.backtester import calculate_metrics, momentum_strategy
from src.models import Direction


def test_momentum_metrics_are_valid():
    close = pd.Series(np.linspace(100, 150, 260))
    metrics = calculate_metrics(close, "TEST")
    assert metrics.symbol == "TEST"
    assert metrics.annualized_return > 0
    assert metrics.max_drawdown <= 0
    assert 0 <= metrics.win_rate <= 1


def test_short_signal_is_negative():
    close = pd.Series([100, 101, 102, 103, 104] * 10, dtype=float)
    signal = momentum_strategy(close, Direction.SHORT, lookback=3)
    assert (signal.dropna() <= 0).all()
