from datetime import datetime, timezone

import pandas as pd
import pytest
from httpx import ASGITransport, AsyncClient

from src.agents import DebateEngine
from src.main import app, run_analysis
from src.models import AgentArgument, AnalyzeRequest, AssetSnapshot, CIOVerdict, Direction, EventRating, IntelligenceSnapshot, BacktestMetrics

class FakeCollector:
    async def collect(self, symbols):
        return IntelligenceSnapshot(assets=[AssetSnapshot(symbol=s, price=100) for s in symbols], collected_at=datetime.now(timezone.utc))

class FakeDebate:
    async def debate(self, event, intelligence, rounds):
        return [AgentArgument(agent="Agent A", stance="bullish", points=["momentum"], confidence=70)]
    async def verdict(self, event, intelligence, debate):
        return CIOVerdict(event_rating=EventRating.MEDIUM, recommended_assets=["SPY"], direction=Direction.LONG, confidence=65, core_logic_summary="test", hedge_recommendation="buy puts")

class FakeBacktester:
    async def run(self, symbol, direction):
        return BacktestMetrics(symbol=symbol, period_days=756, annualized_return=.1, sharpe_ratio=1.0, max_drawdown=-.2, win_rate=.55, trades=12)

@pytest.mark.asyncio
async def test_full_pipeline_injects_backtest():
    briefing = await run_analysis(AnalyzeRequest(event="test event"), FakeCollector(), FakeDebate(), FakeBacktester())
    assert briefing.verdict.backtests[0].symbol == "SPY"
    assert briefing.verdict.direction == Direction.LONG

@pytest.mark.asyncio
async def test_health_endpoint():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get("/healthz")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}

def test_verdict_schema_rejects_invalid_confidence():
    with pytest.raises(ValueError):
        CIOVerdict(event_rating="LOW", recommended_assets=["SPY"], direction="LONG", confidence=101, core_logic_summary="x", hedge_recommendation="y")

@pytest.mark.asyncio
async def test_gemini_json_response_is_validated():
    class FakeModels:
        def generate_content(self, **kwargs):
            class Response:
                text = '{"agent":"Agent A","stance":"bullish","points":["catalyst"],"risks":[],"confidence":80}'
            return Response()
    class FakeClient:
        models = FakeModels()
    engine = DebateEngine(client=FakeClient())
    result = await engine._generate("instruction", "prompt", {"type": "object"})
    assert result["confidence"] == 80
